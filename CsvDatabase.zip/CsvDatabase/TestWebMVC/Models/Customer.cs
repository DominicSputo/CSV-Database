﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestWebMVC.Models
{
    public class Customer
    {
        public string ID { get; set; }
        public string FIRSTNAME { get; set; }
        public string LASTNAME { get; set; }
        public string MIDDLENAME { get; set; }
        public string PHONENUMBER { get; set; }
        public string ROWCOUNT { get; set; }
    }
}